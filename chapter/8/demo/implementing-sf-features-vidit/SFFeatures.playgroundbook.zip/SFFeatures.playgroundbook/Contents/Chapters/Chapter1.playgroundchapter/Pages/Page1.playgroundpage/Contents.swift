/*:
 # Advanced Typographic Options for San Francisco
 This playground is meant to allow the user to easily access, implement and see the effects of the different typographic settings that can be implemented for San Francisco. These include monospaced (tabular) numbers, fractional numbers,  superscripts, subscript, and alternative text styles which include high legibility text and numbers, and alternative glyphs for specific numbers.
 
 - - -
 ## Based on an extension for UI Font
 The syntax for implementing these features is based on an extension for UIFont. The extension is available in the Sources folder of the playground
 */

//#-hidden-code

import Foundation
import UIKit
import PlaygroundSupport

let viewMaster = UIView.init(frame: CGRect(x: 0, y: 0, width: 600, height: 600))
PlaygroundPage.current.liveView = viewMaster
viewMaster.backgroundColor = UIColor(red: 255/255, green: 255/255, blue: 255/255, alpha: 1)

let numberOfLines = 5
let textColor = UIColor(red: 20/255, green: 20/255, blue: 20/255, alpha: 1)
let labelBackgroundColor = UIColor(red: 240/255, green: 240/255, blue: 240/255, alpha: 1)

let descriptionLabelFont = UIFont.boldSystemFont(ofSize: 15).features([.smallCaps_LowerCase, .smallCaps_UpperCase])

var descriptionLabel = UILabel.init(frame: CGRect(x: 20, y: 60, width: 400, height: 30))
descriptionLabel.font = descriptionLabelFont
descriptionLabel.text = "Before Implementing Features"
descriptionLabel.textColor = textColor
viewMaster.addSubview(descriptionLabel)

var noFeatureLabel = UILabel.init(frame: CGRect(x: 20, y: Int(descriptionLabel.frame.maxY),
                                                width: 400, height: 95))
noFeatureLabel.textColor = textColor
noFeatureLabel.numberOfLines = numberOfLines
noFeatureLabel.font = UIFont.systemFont(ofSize: CGFloat(19))
noFeatureLabel.backgroundColor = labelBackgroundColor
noFeatureLabel.layer.cornerRadius = 14
noFeatureLabel.clipsToBounds = true

var descriptionLabel2 = UILabel.init(frame: CGRect(x: 20, y: Int(noFeatureLabel.frame.maxY + 20),
                                                   width: 400, height: 30))
descriptionLabel2.font = descriptionLabelFont
descriptionLabel2.text = "After Implementing Features"
descriptionLabel2.textColor = textColor
viewMaster.addSubview(descriptionLabel2)



var label = UILabel.init(frame: CGRect(x: 20, y: Int(descriptionLabel2.frame.maxY),
                                       width: 400, height: 95))
label.textColor = textColor
label.numberOfLines = numberOfLines
label.backgroundColor = labelBackgroundColor
label.layer.cornerRadius = 14
label.clipsToBounds = true

var text = ""

var fontSize: CGFloat = 19

//#-end-hidden-code
//#-editable-code Tap to write your code

text = "Hello World"
fontSize = 19
label.font = UIFont.systemFont(ofSize: fontSize).features([])

//#-end-editable-code

//#-hidden-code

noFeatureLabel.font = UIFont.systemFont(ofSize: fontSize)
label.text = text
noFeatureLabel.text = text

viewMaster.addSubview(noFeatureLabel)
viewMaster.addSubview(label)
//#-end-hidden-code



