//
//  fontExtension.swift
//  LookUp
//
//  Created by Vidit Bhargava on 03/02/18.
//  Copyright © 2018 The Tangible Apps. All rights reserved.
//

import Foundation
import UIKit

public extension UIFont {
    
    public enum typeFeature {
        case monospacedNumbers
        case superiors
        case inferiors
        case fractional
        case alt6and9
        case open4
        case verticallyCenteredColon
        case highLegibility
        case oneStorey_a
        case smallCaps_LowerCase
        case smallCaps_UpperCase
    }
    
    
    public func features(_ features: [typeFeature]) -> UIFont {
        
        
        var allFeatures: [[String: Int]] = []
        
        for feature in features {
            
            switch feature {
                
            case .monospacedNumbers:
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kNumberSpacingType,
                     UIFontFeatureSelectorIdentifierKey: kMonospacedNumbersSelector]
                )
                
            case .superiors:
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kVerticalPositionType,
                     UIFontFeatureSelectorIdentifierKey: kSuperiorsSelector])
                
            case .inferiors:
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kVerticalPositionType,
                     UIFontFeatureSelectorIdentifierKey: kInferiorsSelector])
                
            case .fractional:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kFractionsType,
                     UIFontFeatureSelectorIdentifierKey: kDiagonalFractionsSelector])
                
            case .alt6and9:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kStylisticAlternativesType,
                     UIFontFeatureSelectorIdentifierKey: kStylisticAltOneOnSelector])
                
            case .open4:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kStylisticAlternativesType,
                     UIFontFeatureSelectorIdentifierKey: kStylisticAltTwoOnSelector])
                
            case .verticallyCenteredColon:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kStylisticAlternativesType,
                     UIFontFeatureSelectorIdentifierKey: kStylisticAltThreeOnSelector])
                
            case .highLegibility:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kStylisticAlternativesType,
                     UIFontFeatureSelectorIdentifierKey: kStylisticAltSixOnSelector])
                
            case .oneStorey_a:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kStylisticAlternativesType,
                     UIFontFeatureSelectorIdentifierKey: kStylisticAltSevenOnSelector])
                
                
            case .smallCaps_LowerCase:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kLowerCaseType,
                     UIFontFeatureSelectorIdentifierKey: kLowerCaseSmallCapsSelector])
                
                
            case .smallCaps_UpperCase:
                
                allFeatures.append(
                    [UIFontFeatureTypeIdentifierKey: kUpperCaseType,
                     UIFontFeatureSelectorIdentifierKey: kUpperCaseSmallCapsSelector])
                
                
            }
            
        }
        
        
        let featureDescriptor = fontDescriptor.addingAttributes([
            UIFontDescriptorFeatureSettingsAttribute : allFeatures
            ])
        
        return UIFont(descriptor: featureDescriptor, size: 0)
    }

}
