//
//  CameraViewController.swift
//  CoreML-Demo
//
//  Created by Bhagat  Singh on 26/05/18.
//  Copyright © 2017 Bhagat  Singh. All rights reserved.
//

import UIKit
import AVFoundation
import CoreML
import Vision

enum FlashState{
  case on
  case off
}


class CameraViewController: UIViewController {
  
  @IBOutlet weak var cameraView: UIView!
  @IBOutlet weak var captureImageView: Rounder_ShadowImageView!
  @IBOutlet weak var identificationLabel: UILabel!
  @IBOutlet weak var confidenceLabel: UILabel!
  @IBOutlet weak var flashButton: Rounded_ShadowButton!
  @IBOutlet weak var backgroundView: Rounded_ShadowView!
  @IBOutlet weak var activityIndicator: UIActivityIndicatorView!
  
  
  var captureSession : AVCaptureSession!
  var cameraOutput : AVCapturePhotoOutput!
  var previewLayer : AVCaptureVideoPreviewLayer!
  var photoData : Data?
  var currentFlashState : FlashState = .off
  var speechSynthesizer = AVSpeechSynthesizer()
  let unknownMessage = "I'm not sure what this is. Try again."
  
  override func viewDidLoad() {
    super.viewDidLoad()
    speechSynthesizer.delegate = self
  }
  
  override func viewDidAppear(_ animated: Bool) {
    super.viewDidAppear(animated)
    previewLayer.frame = cameraView.bounds
    activityIndicator.isHidden = true
  }

  @IBAction func didTapFlashButton(_ sender: Any) {
    
    switch currentFlashState{
    case .on:
      flashButton.setTitle("Flash Off", for: .normal)
      currentFlashState = .off
      
    case .off:
      flashButton.setTitle("Flash On", for: .normal)
      currentFlashState = .on
      
    }
  }
  
  
  
  
  func resultsMethod(request: VNRequest, error:Error?){
    
    // Grab Results from Request
    guard let results = request.results as? [VNClassificationObservation] else {return}

    // Loop through results, and check confidence
    for classification in results {
      if (classification.confidence < 0.5) {
        unknownMessageFunc()
        break
      }
      else {
        let identification = classification.identifier
        let confidence = Int(classification.confidence * 100)
        knownMessageFunc(id: identification, confidence: confidence)
        break
      }
    }
  
    
  }
  
  func knownMessageFunc(id:String, confidence:Int) {
    self.identificationLabel.text = id
    self.confidenceLabel.text = "Confidence : \(confidence)%"
    
    let completeSentence = "This looks like a \(id). I'm \(confidence) percent sure."
    synthesizeSpeech(fromString: completeSentence)
  }
  
  
}

extension CameraViewController : AVCapturePhotoCaptureDelegate{
  
  func photoOutput(_ output: AVCapturePhotoOutput, didFinishProcessingPhoto photo: AVCapturePhoto, error: Error?) {
    
    if let error = error{
      debugPrint(error)
    }
    else {
      
      photoData = photo.fileDataRepresentation()
      
      do {
        // 1. load the model
        let model = try VNCoreMLModel(for:SqueezeNet().model)
        // 2. Create a request with model and handler
        let request = VNCoreMLRequest(model: model, completionHandler: resultsMethod)
        //3. Create a handler for the request
        let handler = VNImageRequestHandler(data: photoData!)
        //4. Perform the request with handler
        try handler.perform([request])
        
      } catch {
        debugPrint(error)
      }
      
      let image = UIImage(data: photoData!)
      self.captureImageView.image = image
    }
  }
}





