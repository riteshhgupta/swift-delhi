//
//  Extensions.swift
//  CoreML-Demo
//
//  Created by Bhagat  Singh on 26/05/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit
import Speech
import CoreML

extension CameraViewController : AVSpeechSynthesizerDelegate{
  
  func speechSynthesizer(_ synthesizer: AVSpeechSynthesizer, didFinish utterance: AVSpeechUtterance) {
    self.cameraView.isUserInteractionEnabled = true
    self.activityIndicator.stopAnimating()
    self.activityIndicator.isHidden = true
  }
}

extension CameraViewController {
  override func viewWillAppear(_ animated: Bool) {
    super.viewWillAppear(animated)
    
    let tapGesture = UITapGestureRecognizer(target: self, action: #selector(didTapCameraView))
    tapGesture.numberOfTapsRequired = 1
    
    captureSession = AVCaptureSession()
    captureSession.sessionPreset = AVCaptureSession.Preset.hd1280x720
    
    let backCamera = AVCaptureDevice.default(for: AVMediaType.video)
    
    do{
      let input = try AVCaptureDeviceInput(device: backCamera!)
      
      if (captureSession.canAddInput(input) == true) {
        captureSession.addInput(input)
      }
      
      cameraOutput = AVCapturePhotoOutput()
      
      if (captureSession.canAddOutput(cameraOutput)) {
        captureSession.addOutput(cameraOutput!)
      }
      
      previewLayer = AVCaptureVideoPreviewLayer(session: captureSession)
      previewLayer.videoGravity = AVLayerVideoGravity.resizeAspect
      previewLayer.connection?.videoOrientation = .portrait
      
      cameraView.layer.addSublayer(previewLayer)
      
      cameraView.addGestureRecognizer(tapGesture)
      
      captureSession.startRunning()
      
      
    }catch{
      debugPrint(error)
    }
    
  }
  
  @objc func didTapCameraView() {
    self.cameraView.isUserInteractionEnabled = false
    self.activityIndicator.isHidden = false
    self.activityIndicator.startAnimating()
    
    let settings = AVCapturePhotoSettings()
    settings.previewPhotoFormat = settings.embeddedThumbnailPhotoFormat
    
    if (currentFlashState == .off) {
      settings.flashMode = .off
      
    }else {
      settings.flashMode = .on
    }
    
    cameraOutput.capturePhoto(with: settings, delegate: self)
    
  }
  
  func synthesizeSpeech(fromString string:String){
    
    let speechUtterance = AVSpeechUtterance(string: string)
    speechSynthesizer.speak(speechUtterance)
  }
  
  func unknownMessageFunc() {
    self.identificationLabel.text = unknownMessage
    self.confidenceLabel.text = ""
    synthesizeSpeech(fromString: unknownMessage)
  }
  
}
