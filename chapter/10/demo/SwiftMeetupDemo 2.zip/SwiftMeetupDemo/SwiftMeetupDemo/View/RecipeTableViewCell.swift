//
//  RecipeTableViewCell.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

class RecipeTableViewCell: UITableViewCell {

  
  @IBOutlet weak var recipeImageView: UIImageView!
  

}
