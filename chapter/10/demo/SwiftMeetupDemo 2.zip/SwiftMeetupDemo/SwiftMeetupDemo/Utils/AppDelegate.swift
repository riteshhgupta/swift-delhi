//
//  AppDelegate.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

@UIApplicationMain
class AppDelegate: UIResponder, UIApplicationDelegate {

  var window: UIWindow?


  func application(_ application: UIApplication, didFinishLaunchingWithOptions launchOptions: [UIApplicationLaunchOptionsKey: Any]?) -> Bool {
    return true
  }
  
}

