//
//  Extensions.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

extension HomeViewController {
  
  func constructData() {
    for i in 0...14 {
      let recipe = Recipe(recipeName: recipeNames[i%7], recipeImage: "\(i%7 + 1)")
      recipes.append(recipe)
    }
  }
}

extension HomeViewController : UITableViewDataSource, UITableViewDelegate {
  
  func numberOfSections(in tableView: UITableView) -> Int {
    return 1
  }
  
  func tableView(_ tableView: UITableView, numberOfRowsInSection section: Int) -> Int {
    return recipes.count
  }
  
  func tableView(_ tableView: UITableView, cellForRowAt indexPath: IndexPath) -> UITableViewCell {
    let cell = tableView.dequeueReusableCell(withIdentifier: "cell", for: indexPath) as! RecipeTableViewCell
    cell.recipeImageView.image = UIImage(named: recipes[indexPath.row].recipeImage!)
    
    return cell
  }
  
  func tableView(_ tableView: UITableView, didSelectRowAt indexPath: IndexPath) {
    performSegue(withIdentifier: "toDetailVC", sender: self)
  }
  
}
