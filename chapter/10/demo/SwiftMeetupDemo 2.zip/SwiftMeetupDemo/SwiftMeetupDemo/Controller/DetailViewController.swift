//
//  DetailViewController.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

class DetailViewController: UIViewController {

  @IBOutlet weak var recipeImage: UIImageView!
  @IBOutlet weak var recipeTitle: UILabel!
  
  var recipe : Recipe!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    recipeImage.clipsToBounds = true
    
    if let photo = recipe.recipeImage, let name = recipe.recipeName {
      recipeImage.image = UIImage(named: photo)
      recipeTitle.text = name
    } 
  }
  
  
  
}
