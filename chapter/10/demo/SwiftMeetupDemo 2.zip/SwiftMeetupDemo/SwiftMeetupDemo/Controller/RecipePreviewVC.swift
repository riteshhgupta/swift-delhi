//
//  RecipePreviewVC.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 20/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

class RecipePreviewVC: UIViewController {

  var recipe: Recipe!
  
  @IBOutlet weak var recipeImage: UIImageView!
  @IBOutlet weak var recipeLabel: UILabel!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    recipeImage.clipsToBounds = true
    
    if let name = recipe.recipeName, let photo = recipe.recipeImage {
      recipeImage.image = UIImage(named: photo)
      recipeLabel.text = name
    }
  }
  
  /*
  override var previewActionItems: [UIPreviewActionItem] {

    let action1 = UIPreviewAction(title: "Ok", style: .default) { (action, controller) in
      print("Action Ok Selected")
    }

    let action2 = UIPreviewAction(title: "Favourite", style: .default) { (action, controller) in
      print("Action Favourite Selected")
    }

    let action3 = UIPreviewAction(title: "Cancel", style: .destructive) { (action, controller) in
      print("Action Cancel Selected")
    }

    return  [action1, action2, action3]
  }
 */
  
}
