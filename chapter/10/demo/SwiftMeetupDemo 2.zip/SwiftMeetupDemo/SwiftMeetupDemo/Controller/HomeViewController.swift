//
//  ViewController.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

class HomeViewController: UIViewController {

  @IBOutlet weak var tableView: UITableView!
  
  var recipes = [Recipe]()
  var recipeNames = ["Delicious Salad", "Hot Casserole", "Shepherd's Pie", "Egg Rolls", "Delicious Paella", "Authentic Mexican", "Mexican Paella"]
  var selectedIndexPath : IndexPath!
  
  override func viewDidLoad() {
    super.viewDidLoad()
    
    tableView.delegate = self
    tableView.dataSource = self
    
    checkFor3dTouch()
    
    constructData()
  }
}

extension HomeViewController : UIViewControllerPreviewingDelegate {
  
  func previewingContext(_ previewingContext: UIViewControllerPreviewing, viewControllerForLocation location: CGPoint) -> UIViewController? {
    
    guard
      let indexPath = tableView.indexPathForRow(at: location),
      
      let cell = tableView.cellForRow(at: indexPath),
    
      let previewVC = storyboard?.instantiateViewController(withIdentifier: "detailVC") as? DetailViewController
    
      else { return nil }
    
    
    let recipe = recipes[indexPath.row]
    
    previewVC.recipe = recipe
    
    previewVC.preferredContentSize = CGSize(width: 300, height: 300)
    
    previewingContext.sourceRect = cell.frame
    
    selectedIndexPath = indexPath
    
    return previewVC

  }
  
  
  func previewingContext(_ previewingContext: UIViewControllerPreviewing, commit viewControllerToCommit: UIViewController) {
    /*
    let recipe = recipes[(selectedIndexPath.row)]
    let vc = storyboard?.instantiateViewController(withIdentifier: "detailVC") as! DetailViewController
    vc.recipe = recipe
  */
    show(viewControllerToCommit, sender: self)
  }
}

extension HomeViewController {
  
  func checkFor3dTouch() {
    if traitCollection.forceTouchCapability == .available {
      registerForPreviewing(with: self, sourceView: tableView)
    }
    
    /*else if longPressFallback {
      applyLongPressGesture(to view: tableView)
    }*/
    
  }
  
  override func prepare(for segue: UIStoryboardSegue, sender: Any?) {
    if segue.identifier == "toDetailVC" {
      let indexpath = tableView.indexPathForSelectedRow
      let recipe = recipes[(indexpath?.row)!]
      let vc = segue.destination as! DetailViewController
      vc.recipe = recipe
    }
  }

}
