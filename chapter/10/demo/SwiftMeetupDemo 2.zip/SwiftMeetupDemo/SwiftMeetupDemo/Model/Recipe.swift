//
//  Recipe.swift
//  SwiftMeetupDemo
//
//  Created by Bhagat  Singh on 15/04/18.
//  Copyright © 2018 Bhagat Singh. All rights reserved.
//

import UIKit

class Recipe {
  
  var recipeName : String?
  var recipeImage : String?
  
  init(recipeName: String, recipeImage: String) {
    self.recipeName = recipeName
    self.recipeImage = recipeImage
  }
  
}
